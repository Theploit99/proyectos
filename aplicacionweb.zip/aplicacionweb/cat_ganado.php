<?php
//se incluye archivo de conexion por medio de include
include 'conexion.php';
include 'menu_admin.php';
//Consulta de Registro dados de alta
$consulta="select * from ganado" ;
$resultado=mysqli_query($conexion, $consulta);
// o tambien $resultado=mysqli_query($conexion, "select * from empleados");
$nfilas=mysqli_num_rows($resultado);
error_reporting(0);

//Eliminar registro
if (isset($_REQUEST['eliminar'])) {

    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion, "delete from ganado where id_ganado=$eliminar");
    echo '<script>alert("Registro eliminado");</script>';
    echo "<script>window.location='cat_ganado.php'</script>";
}

	//Editar registro

	if (isset($_REQUEST['editar'])) {
		$editar=$_REQUEST['editar'];
		$registros=mysqli_query($conexion, "select * from ganado where id_ganado=$editar");
        $reg=mysqli_fetch_array($registros);


$actualizar = ("UPDATE ganado set id_ganado=$id_ganado,nombre='$nombre', peso='$peso', color='$color', where id_ganado='$id_ganado'");

$resultado=mysqli_query($conexion,$resultado);
if(!$resultado){
    echo '<script>alert("Error al editar el Registro ");</script>';
    echo "<script>window.location='cat_ganado.php'</script>";
}else{
    echo '<script>alert("Registro actualizado correctamente");</script>';
    echo "<script>window.location='cat_ganado.php'</script>";
}
    }


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Ganado - Rancheria "Los Tulipanes"</title>
</head>
<link rel="stylesheet" href="css/css.css">
<body>
<section id="consulta" style="margin-left : 100px;">
<header>
    <h2 style="color:white; text-align:center;">Poblacion Animal que existe aqui</h2>
</header>
<section id="general" style="margin-left : 50px;">

      <form action="fun_ganado.php" method="post" enctype="multipart/form-data">
           <input type="text" name="color" placeholder="color" size="30">
           <input type="text" name="peso" placeholder="peso" size="35">
            <label for="especie">Especie</label>
            <select name="especie" >
                <option value="Vacuno">Vacuno</option>
                <option value="Equino">Equino</option>
            </select> <br/>
             <label for="raza">raza:</label>
             <select name="raza">
               <option value="Beefmaster">Beefmaster</option>
               <option value="Charolais">Charolais</option>
               <option value="Simmental">Simmental</option>
               <option value="Apaloosa">Apaloosa</option>
               <option value="Árabe-portugués">Árabe-portugués</option>
               <option value="Azteca">Azteca</option>
             </select>
           <label for="sexo">Sexo:</label>
           <select  name="sexo">
             <option value="Macho">Macho</option>
             <option value="Hembra">Hembra</option>
           </select>
            <label for="vacuna " >vacuna:</label>
            <select  name="vacuna">
                 <option value="Influenza Equina">Influenza Equina</option>
                 <option value="Rabia">Rabia</option>
                 <option value="Rinotraqueitis Infecciosa Bovina">Rinotraqueitis Infecciosa Bovina</option>
                 <option value="Virus del Oeste de Nilo">Virus del Oeste de Nilo</option>
                 <option value="Diarrea Viral Bovina">Diarrea Viral Bovina</option>
                 <option value="NO">Sin Vacuna</option>
            </select> <br/>
            <label for="foto">Foto del Animal</label>
            <input type="file" name="foto">
           <input type="submit" value="agregar"></input>
       </form>

      </form>
          <table style="color:white; text-align:center;  width: 100%; border: 1px solid #fff; font-size:18px;">
              <tr >
                  <td>No.</td>
                  <td>Foto</td>
                  <td>Peso</td>
                  <td>Color</td>
                  <td>Especie</td>
                  <td>Raza</td>
                  <td>Vacuna</td>
                  <td>Sexo</td>
                  <td>Eliminar</td>

              </tr>
              <?php while ($ganado=mysqli_fetch_array($resultado)) {  ?>
                <tr>
                  <td> <a href="detalle_ganado.php?id_ganado=<?php echo $ganado['id_ganado'];?>"><?php echo $ganado['id_ganado']; ?></a></td>
                  <td><img src="<?php echo $ganado['foto'];  ?>"alt="muuu" style="height = "80"; width="95""></td>
                  <td><?php    echo $ganado['peso'];    ?></td>
                  <td><?php    echo $ganado['color'];    ?></td>
                 <td><?php    echo $ganado['especie'];    ?></td>
                  <td><?php    echo $ganado['raza'];    ?></td>
                  <td><?php    echo $ganado['vacuna'];    ?></td>
                   <td><?php    echo $ganado['sexo'];    ?></td>
                   <td><a href="cat_ganado.php?eliminar=<?php echo $ganado['id_ganado']; ?> ">Eliminar</td>
              </tr>
              <?php  }  ?>

          </table>
</section>
</section>

<?php //codigo fuente otorgado por la ISC. Ana Aurora Guerrero Gonzalez ?>


<footer>
        <div class="pie">
            <p style="text-align: center;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
        </div>
    </footer>
</body>
</html>
