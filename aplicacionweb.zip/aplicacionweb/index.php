<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inicio - Rancheria "Los Tulipanes"</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;1,400;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/vistas.css">
</head>

<body>
    
    
    
    <!-- inicio Menu-->
  <?php include 'menu.php'; ?>
    <!-- Fin Menu-->

    

    <div class="contenidos">
        <figure>
            <img src="imagenes/rancho.jpg" alt="Rancho">
            <div class="capa">
                <h3>Rancho "Los Tulipanes"</h3>
                <p>
                    Fundada en 1978 por el licenciado Roman Priego Esquivel junto a su Esposa la Sra. Araceli Suarez Lopez, este rancho ha
                    el fruto de sus esfuerzo para llevar la excelente calidad de Ganado Tabasqueño.

            </div>
        </figure>
    </div>


    <section style="color: white;">



        <section class="ganado contenedor">
            <h2 class="titulo">Ganado</h2>
            <div class="cards">
                <div class="card">
                    <img src="imagenes/test2.jpg" alt="Ganado Vacuno">
                    <div class="contenido-texto-card">
                        <h4>Ganado Vacuno</h4>
                        <p>Ganado vacuno, nombre común de los mamíferos herbívoros domesticados del género Bos, de la familia Bóvidos,
                            que tienen gran importancia para el hombre, quien obtiene de ellos carne, leche, cuero, cola,
                            gelatina y otros productos comerciales </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="ganado contenedor">
            <div class="cards">
                <div class="card">
                    <img src="imagenes/tes1.jpg" alt="Ganado Equino">
                    <div class="contenido-texto-card">
                        <h4>Ganado Equino</h4>
                        <p>EL Ganado equino pueden clasificarse, según su origen geográfico, en dos grandes grupos: orientales y occidentales, y según sus funciones,
                            en caballos de silla y caballos de tiro. Los caballos de silla pueden demostrar una serie de aptitudes distintas, tales como trabajo de campo,
                            ejército, paseo, carrera, polo, salto y caza. </p>
                    </div>
                </div>
            </div>
        </section>



        <footer>
            <div>
                <redes style="color: white;">
                    <p1><img src="PNG/facebook.png" alt="facebook" width="20px" height="20px;"> https://www.facebook.com/lostulipanessomostodos </p1>
                    <p1><img src="PNG/telefono.png" alt="telefono" width="20px" height="20px;"> 9931838301 </p1>
                    <p1><img src="PNG/correo.png" alt="correo" width="20px" height="20px;"> RanchoTulipanes@gmail.com </p1>
                </redes>

                <p style="text-align: center; color: white;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
            </div>
        </footer>
</body>

</html>
