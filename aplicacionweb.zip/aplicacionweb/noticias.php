<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Noticias - Rancheria "Los Tulipanes"</title>
    <link rel="stylesheet" href="css/vistas.css">
    
</head>
<body>
            
    <!-- inicio Menu-->
  <?php include 'menu.php'; ?>
    <!-- Fin Menu-->
          
    <div class="contenidos">
        <figure>
            <img src="imagenes/noti1.jpg" alt="Noticias">
            <div class="capa">
                <h3>Lluvias matan de hambre a reses de Nacajuca</h3>
                <p>
                    Nacajuca, Tabasco.-La inundación prolongada que se ha presentado en los ejidos y ranchos ganaderos de las diferentes comunidades de Nacajuca,
                     ha provocado la muerte de varias reses, debido a la falta de pasto y terrenos en donde los semovientes permanezcan parados.

            </div>
        </figure>
    </div>


<div class="contenidos">
        <figure>
            <img src="imagenes/noti2.jpeg" alt="Noticias">
            <div class="capa">
                <h3>Integrar a pequeños productores en esquemas de exportación; el reto en la ganadería y la porcicultura mexicana</h3>
                <p>
                    Durante el segundo día de actividades de la XLIX Convención Anual de la INFARVET, la convocatoria dentro de la ganadería
                     y la porcicultura fue en el sentido de impulsar la participación de los pequeños y medianos productores en actividades comerciales.

            </div>
        </figure>
    </div>
      <footer>
            <div>
                <redes style="color: white;">
                    <p1><img src="PNG/facebook.png" alt="facebook" width="20px" height="20px;"> https://www.facebook.com/lostulipanessomostodos </p1>
                    <p1><img src="PNG/telefono.png" alt="telefono" width="20px" height="20px;"> 9931838301 </p1>
                    <p1><img src="PNG/correo.png" alt="correo" width="20px" height="20px;"> RanchoTulipanes@gmail.com </p1>
                </redes>

                <p style="text-align: center; color: white;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
            </div>
        </footer>
    
</body>
</html>