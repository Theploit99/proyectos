<?php
//se incluye archivo de conexion a la base de datos (ganado)
include 'conexion.php';
error_reporting(0);
//almacenar datos en variables obtenidas por medio de post
$foto = $_POST["foto"];
$nombre = $_POST ["nombre"];
$apellido = $_POST["apellido"];
$correo = $_POST["correo"];
$password = $_POST["password"];
$telefono = $_POST["telefono"];
$direccion = $_POST ["direccion"];

//hacer la consulta y la insersion de datos a la base de datos de los campos solicitados

$insertar = "INSERT INTO usuarios(foto, nombre,apellido,correo,contraseña,telefono,direccion)
VALUES ('$foto','$nombre','$apellido','$correo','$password','$telefono','$direccion')";




//verificar si el correo ya existe
$verificar_usuario = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo = '$correo' ");
if (mysqli_num_rows($verificar_usuario)  > 0 ){
    echo 'El correo ya existe, utilice otro por favor';
    //recuerda declarar el exit dentro de la condicion
    //porque ya me paso que se cerraba y solo me mandaba el mensaje de la conexion exitosa xd
    exit;
  }
 //ejecutamos la insercion de los datos
   $resultado = mysqli_query ($conexion, $insertar);
if (!$resultado){
  //aqui decimos que puede que este fallando algo y nos mande error
echo '<script>';
echo 'alert("Error Al Registrarse al usuario, comuniquese a Sistemas");';
echo 'window.location.href="cat_usuario.php";';
echo '</script>';
}
else{
  //aqui pues seria que correctamente se insertaron los datos
  echo '<script>';
	echo 'alert("Registrado Correctamente");';
	echo 'window.location.href="cat_usuario.php";';
	echo '</script>';
}

?>
