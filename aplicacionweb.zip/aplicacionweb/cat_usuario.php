<?php
//se incluye archivo de conexion por medio de include
include 'conexion.php';
//se incluye la barra de navegacion de la version de administrador
include 'menu_admin.php';
//Consulta de Registro dados de alta
$consulta="select * from usuarios";
$resultado=mysqli_query($conexion, $consulta);
// o tambien $resultado=mysqli_query($conexion, "select * from empleados");
$nfilas=mysqli_num_rows($resultado);



//Eliminar el registro en la tabla usuarios en la base de datos
if (isset($_REQUEST['eliminar'])) {
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion, "delete from usuarios where id_usuarios=$eliminar");
    echo '<script>alert("Registro eliminado");</script>';
    echo "<script>window.location='cat_usuario.php'</script>";
}
	//Editar registro en la tabla usuarios en la base de datos
	if (isset($_REQUEST['editar'])) {
		$editar=$_REQUEST['editar'];
		$registros=mysqli_query($conexion, "select * from usuarios where id_usuarios=$editar");
        $reg=mysqli_fetch_array($registros);


$actulizar= "UPDATE usuarios set id_usuarios=$id_usuario,nombre='$nombre', apellido='$apellido', correo='$correo',telefono='$telefono',direccion='$direccion' where id_usuarios='$id_usuario'";

$resultado=mysqli_query($conexion,$actualizar);
if(!$resultado){
    echo '<script>alert("Error al editar el Registro ");</script>';
    echo "<script>window.location='cat_usuario.php'</script>";
}else{
    echo '<script>alert("Registro actualizado correctamente");</script>';
    echo "<script>window.location='cat_usuario.php'</script>";
}
    }


error_reporting(0);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Usuarios - Rancheria "Los Tulipanes"</title>
</head>
<link rel="stylesheet" href="css/css.css">
<body>
<section id="consulta">
<header>
    <h2 style="color:white; text-align:center;">Datos de los usuarios dados de Alta en el Sistema</h2>
</header>
<section id="general">

      <form action="fun_registro1.php" method="post" enctype="application/x-www-form-urlencoded">

          <input type="text" name="nombre" placeholder="Nombre" size="20">
          <input type="text" name="apellido" placeholder="apellido" size="30">
          <input type="text" name="correo" placeholder="email" size="35">
          <input type="text" name="direccion" placeholder="direccion" size="80">
          <input type="text" name="telefono" placeholder="No. Telefono" size="10"><br/>
          <input type="submit" value="Agregar"></input>
      </form>
          <table style="color:white; text-align:center;  width: 100%; border: 1px solid #fff; font-size:18px;">
              <tr>
                  <td>No. </td>
                  <td>Nombre</td>
                  <td>Apellido</td>
                  <td>Correo</td>
                  <td>Direccion</td>
                  <td>Telefono de contacto</td>
                  <td>Eliminar</td>
              </tr>
              <?php while ($usuario=mysqli_fetch_array($resultado)) {  ?>
                <tr>
                  <td> <a href="detalle_usuario.php?id_usuarios=<?php echo $usuario['id_usuarios'];  ?> "><?php echo $usuario['id_usuarios']; ?></a></td>
                  <td><?php    echo $usuario['nombre'];    ?></td>
                  <td><?php    echo $usuario['apellido'];    ?></td>
                  <td><?php    echo $usuario['correo'];    ?></td>
                  <td><?php    echo $usuario['direccion'];    ?></td>
                  <td><?php    echo $usuario['telefono'];    ?></td>
                  <td><a href="cat_usuario.php?eliminar=<?php echo $usuario['id_usuarios']; ?> ">Eliminar</td>
              </tr>
              <?php  }  ?>

          </table>
</section>
</section>s

<?php //codigo fuente otorgado por la ISC. Ana Aurora Guerrero Gonzalez ?>



</body>
</html>
