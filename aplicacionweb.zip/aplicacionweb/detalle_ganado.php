<?php
include 'conexion.php';
include 'menu_admin.php';
error_reporting(0);
$ganado=$_GET['id_ganado'];
$consulta="select * from ganado where id_ganado = $ganado";
$resultado=mysqli_query($conexion, $consulta);
$ganado=mysqli_fetch_assoc($resultado);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle del animal</title>
    <link rel="stylesheet" href="css/css.css">
</head>
<body>
    <section id="general">
        <header>
            <h2>DETALLES DEL ANIMAL</h2>
        </header>
        <table>
            <tr>
                <td>No:</td>
                <td><?php echo $ganado ['id_ganado'];?></td>
            </tr>
            <tr>
                <td>Foto:</td>
               <td><img src="<?php echo $ganado['foto'];  ?>"alt="muuu" style="height = "210"; width="235""></td>
            </tr>
            <tr>
                <td>Peso:</td>
                <td><?php echo $ganado['peso'];?></td>
            </tr>
            <tr>
                <td>Color:</td>
                <td><?php echo $ganado ['color']; ?></td>
            </tr>
            <tr>
                <td>especie:</td>
                <td><?php echo $ganado ['especie']?></td>
            </tr>
            <tr>
                <td>raza:</td>
                <td><?php echo $ganado['raza']?></td>
            </tr>
            <tr>
                <td>vacuna:</td>
                    <td><?php echo $ganado['vacuna']?></td>
            </tr>
            <tr>
              <tr>
                  <td>sexo:</td>
                      <td><?php echo $ganado['sexo']?></td>
              </tr>
                <td> <a href="cat_ganado.php">Regresars</a></td>
                <td></td>
            </tr>
        </table>
    </section>
</body>
</html>
