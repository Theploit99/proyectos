<?php
$conexion=mysqli_connect("localhost","root","","ganaderia");

if($conexion === false){
    die("Error en la conexion a la base de datos, Disculpe las molestias :/" . mysqli_connect_error());
}else{
    echo'';
}


//SI ( la conexion es falsa)
// ENTONCES escribir "La conexion ha fallado" escribir "la conexion es exitosa"
//SINO
//escribir "la conexion es exitosa"



?>
