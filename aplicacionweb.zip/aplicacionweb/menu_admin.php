<section>
 <header>
     <nav id="contenedor">
         <a href="index.php" class="nav-enlace" img>Inicio</a>
         <a href="cat_ganado.php" class="nav-enlace">Ganados</a>
         <a href="cat_usuario.php" class="nav-enlace">usuarios</a>
         <a href="cat_comentario.php" class="nav-enlace">Comentarios</a>
         <a href="cerrar_sesion.php" class="nav-enlace">Cerrar Sesion</a>
     </nav>

 </header>
</section>
