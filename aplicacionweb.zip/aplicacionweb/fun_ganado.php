<?php
//se incluye archivo de conexion a la base de datos (ganado)
include 'conexion.php';


//almacenar datos en variables obtenidas por medio de post

$peso = $_POST["peso"];
$color = $_POST["color"];
$especie = $_POST["especie"];
$raza = $_POST["raza"];
$vacuna = $_POST ["vacuna"];
$sexo = $_POST["sexo"];
$subio = false ;
//agregar incersion de imagen a la bd a traves de la consulta

  $foto = $_FILES ['foto']['type'];
  $temp = $_FILES ['foto']['tmp_name'];
  $directorio='archivos';
  $foto=$directorio."/".$_FILES['foto']['name'];
  if (is_uploaded_file($_FILES['foto']['tmp_name'])) {
  move_uploaded_file($_FILES['foto']['tmp_name'], $foto);

$insertar = "INSERT INTO ganado(foto,peso,color,especie,raza,vacuna,sexo) VALUES ('$foto','$peso','$color','$especie','$raza','$vacuna','$sexo')";
$resultado = mysqli_query ($conexion, $insertar);
if (!$resultado){
echo '<script>';
echo 'alert("Error Al Registrar al animal, Intentelo Más Tarde");';
echo 'window.location.href="cat_ganado.php";';
echo '</script>';
  //aqui decimos que puede que este fallando algo y nos mande error

}else{
  //aqui pues seria que correctamente se insertaron los datos
  echo '<script>';
	echo 'alert("Registrado Correctamente :D");';
	echo 'window.location.href="cat_ganado.php";';
	echo '</script>';
}
}


//hacer la consulta y la insersion de datos a la base de datos de los campos solicitados

//$insertar = "INSERT INTO ganado(foto,peso,color,especie,raza,vacuna,sexo) VALUES ('$foto','$peso','$color','$especie','$raza','$vacuna','$sexo')";

//ejecutamos la insercion de los datos
  // $resultado = mysqli_query ($conexion, $insertar);
//if (!$resultado){
  //aqui decimos que puede que este fallando algo y nos mande error
//echo '<script>';
//echo 'alert("Error Al Registrar al animal, Intentelo Más Tarde");';
//echo 'window.location.href="cat_ganado.php";';
//echo '</script>';
//}
//else{
  //aqui pues seria que correctamente se insertaron los datos
  //echo '<script>';
	//echo 'alert("Registrado Correctamente :D");';
	//echo 'window.location.href="cat_ganado.php";';
	//echo '</script>';
//}
 ?>
