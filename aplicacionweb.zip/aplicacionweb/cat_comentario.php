<?php
include 'menu_admin.php';
include 'conexion.php';

$consulta="select * from comentario";
$resultado=mysqli_query($conexion, $consulta);
$nfilas=mysqli_num_rows($resultado);
if (isset($_REQUEST['eliminar'])) {
    
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion, "delete from comentario where id_comentario=$eliminar");
    echo '<script>alert("Registro eliminado");</script>';
    echo "<script>window.location='cat_comentario.php'</script>";
}
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comentarios - Rancheria "Los Tulipanes"</title>
    <link rel="stylesheet" href="css/css.css">
</head>
<body>

<p style="text-align:center; color:white;">BIENVEIDO A LA SECCION DE COMENTARIOS</p>


<table>
<tr>
<td>Numero</td>
<td>Nombre</td>
<td>Comentario</td>
<td>Eliminar</td>
</tr>
<?php while($comentario=mysqli_fetch_array($resultado)) {  ?>
               <tr>
                 <td><?php echo $comentario['id_comentario']; ?></a></td>
                 <td><?php echo $comentario['nombre'];    ?></td>
                 <td><?php echo $comentario['comentario'];    ?></td>
                 <td><a href="cat_comentario.php?eliminar=<?php echo $comentario['id_comentario']; ?> ">Eliminar</td>

             </tr>
             <?php  }  ?>
</table>
</body>
</html>