<?php

//se incluye la barra de navegacion en menu.php y la conexion a la base de datos en conexion.php
include 'menu.php';
include 'conexion.php';

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/vistas.css">
    <title>Registro - Rancheria "Los Tulipanes"</title>
</head>
<body>

  <p style="color:white; text-align:center;">Bienvenido, Ingrese los datos a continuación</p>

<section id="formulario">
    <form action="fun_registro.php" method="post">
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="apellido" placeholder="Apellidos">
        <input type="text" name="direccion" placeholder="Dirección">
        <input type="text" name="telefono" placeholder="Número Telefonico">
        <input type="email" name="correo" placeholder="Correo Electronico">
        <input type="password" name="password" placeholder="Cree una contraseña">
        <input type="submit" value="enviar" id="boton">
    </form>
</section><br/>
    
    
  <footer style="position:absolute;">
            <div>
                <redes style="color: white;">
                    <p1><img src="PNG/facebook.png" alt="facebook" width="20px" height="20px;"> https://www.facebook.com/lostulipanessomostodos </p1>
                    <p1><img src="PNG/telefono.png" alt="telefono" width="20px" height="20px;"> 9931838301 </p1>
                    <p1><img src="PNG/correo.png" alt="correo" width="20px" height="20px;"> RanchoTulipanes@gmail.com </p1>
                </redes>

                <p style="text-align: center; color: white;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
            </div>
        </footer>
</body>
</html>
