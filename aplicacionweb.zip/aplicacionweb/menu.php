       <section>
        <header>
            <h1 style="float:right" class="ellogo">Rancho "Los Tulipanes"</h1>
            <nav id="contenedor">
                <a href="index.php" class="nav-enlace" img> <img src="PNG/inicio.png" alt="" style="height: 15px; width: 15px;">Inicio</a>
                <a href="ventas.php" class="nav-enlace"> <img src="PNG/ventas.png" alt="" style="height: 15px; width: 15px;"> Ventas</a>
                <a href="conocenos.php" class="nav-enlace"> <img src="PNG/conocenos.png" alt="" style="height: 15px; width: 15px;">Conocenos</a>
                <a href="login.php" class="nav-enlace"> <img src="PNG/login.png" alt="" style="height: 15px; width: 15px;">Login</a>
                <!--<a href="noticias.php" class="nav-enlace"><img src="PNG/noticias.png" alt="" style="height: 15px; width: 15px;"> Noticias</a>--->
            </nav>
        </header>
    </section>
