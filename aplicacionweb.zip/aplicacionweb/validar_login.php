<?php
	session_start();// Se inicia una sesión
	include 'conexion.php';
	$_SESSION['correo']=$_POST['correo'];
	$_SESSION['password']=$_POST['password'];

	$consulta= "select * from usuarios where correo='$_SESSION[correo]' and password='$_SESSION[password]'";

	$usuarios=mysqli_query($conexion, $consulta);
	$filas=mysqli_num_rows($usuarios);


	if ($filas>0) {
		# code...
		//Guardamos los datos del registro que nos devuelve la consulta en un array
		$datos=mysqli_fetch_array($usuarios);
		//Definir una variable de sesion
		$_SESSION['nombre']=$datos['nombre'];
		header("location:menu_admin.php");
		//ó
		// echo "<script>window.location='menu_admon.php'</script>";
	} else{
		mysqli_close($conexion);
		echo "<script>alert('Usuario no valido')</script>";
		echo "<script>window.location='login.php'</script>";
		session_destroy();
	}

	mysqli_free_result($usuarios);//Libera los resultados para no consumir memoria



 ?>
