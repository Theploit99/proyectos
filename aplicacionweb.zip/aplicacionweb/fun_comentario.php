<?php
// se incluye archivo de conexion a la base de datos para la consulta de comentarios
include 'conexion.php';


$nombre = $_POST["nombre"];
$mensaje=$_POST["mensaje"];

$insertar = "INSERT INTO comentario(nombre,comentario)VALUES ('$nombre','$mensaje')";

$resultado = mysqli_query($conexion, $insertar);
if (!$resultado){
  //aqui decimos que puede que este fallando algo y nos mande error
echo '<script>';
echo 'alert("Error Al Registrar el comentario, Intentelo Más Tarde");';
echo 'window.location.href="conocenos.php";';
echo '</script>';
}
else{
  //aqui pues seria que correctamente se inserto el comentario
  echo '<script>';
	echo 'alert("Comentario Registrado Correctamente :D");';
	echo 'window.location.href="conocenos.php";';
	echo '</script>';
}

 ?>
