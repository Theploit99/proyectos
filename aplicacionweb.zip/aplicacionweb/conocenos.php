<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conocenos - Rancheria "Los Tulipanes"</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;1,400;1,700&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="css/vistas.css">

</head>

<body>

    <!-- inicio Menu-->
  <?php include 'menu.php'; ?>
    <!-- Fin Menu-->

<!-- inicio de contenido de pagina -->

<section>

    <div >
        <h2 style="text-align:center;">Sobre Nosotros</h2>
        <p style="color:white; padding-left:100px; padding-right:100px; justify-content:justify;">Somos una empresa con el objetivo claro de ser la empresa numero uno en el mercado ganadero 100% Tabasqueña, con las caracteristicas que nos definen como es la calidad y precio que nos distiguen de cualquiera en el mercado, apuntamos expandir nuestras ventas a nivel Nacional e internacional para mostrar que Tabasco cuenta la mejor calidad que se pueda dar en cuanto a precio-calidad nos enfocamos. Gracias a la ubicacion geografica de Tabasco el cual influye en la calidad de la tierra y por ellos en la alimentacion de nuestro ganado el cual lo hace ser de una calidad de primer nivel. </p>
    </div>

    <div>
        <ul style=" color:white; display: inline-block; overflow: auto; list-style:none; display: flex; flex-direction: rows;  align-items:center; text-align:center;">
            <li style="display:inline-block;">
                <h4>Mision:</h4>
                <p> La misión de nuestra empresa consiste en dar renombre a nuestra tierra tabasqueña como un punto comercial de la mejor calidad que se pueda dar en esta parte del pais gracias a las manos paisanas y a la riqueza que brinda nuestras tierras gracias a su clima favorable para la crianza de ganado.</p>

            </li>
            <li>
                <h4 >Vision:</h4>
                <p>Nuestra visión consiste en lograr expotar nuestro ganado por toda la republica mexicana con el gran renombre de nuestra tierra Tabasqueña y posicionarnos en le mercado a nivel nacional.</p>
            </li>
            <li>
                <h4>
                    <h4>Valores:</h4>
                    <p>Excelencia, Calidad, Lealtad, Compromiso y Responsabilidad. Estos son los valores que nos definen como empresa y nos dan brindan las riendas para seguir progresando.</p>
                </h4>
            </li>
        </ul>
    </div>
</section>
<!-- fin de contenido de pagina -->


<form style="width: 70%;
    margin-bottom: 20px;
    padding: 7px;
    box-sizing: border-box;
    font-size: 20px;
    color:white;
    text-align: center;
    display: inline-block;
    margin-left: 300px;
    " action="fun_comentario.php" method="post">
        <p>Ingrese su Nombre</p><br/>
        <input type="text" name="nombre">
        <p>Escriba su comentario </p><br/>
        <textarea name="mensaje" cols="50" rows="10"></textarea>
        <input type="submit" value="Enviar">
</form>


<!-- pie de pagina -->
  <footer>
            <div>
                <redes style="color: white;">
                    <p1><img src="PNG/facebook.png" alt="facebook" width="20px" height="20px;"> https://www.facebook.com/lostulipanessomostodos </p1>
                    <p1><img src="PNG/telefono.png" alt="telefono" width="20px" height="20px;"> 9931838301 </p1>
                    <p1><img src="PNG/correo.png" alt="correo" width="20px" height="20px;"> RanchoTulipanes@gmail.com </p1>
                </redes>

                <p style="text-align: center; color: white;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
            </div>
        </footer>
</body>
</html>
