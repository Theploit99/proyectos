<?php
include 'conexion.php';
include 'menu_admin.php';
error_reporting(0);
$usuario=$_GET['id_usuarios'];
$consulta="select * from usuarios where id_usuarios = $usuario";
$resultado=mysqli_query($conexion, $consulta);
$usuario=mysqli_fetch_assoc($resultado);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle del Usuario</title>
    <link rel="stylesheet" href="css/css.css">
</head>
<body>
    <section id="general">
        <header>
            <h2>DETALLES DEL USUARIO</h2>
        </header>
        <table>
            <tr>
                <td>ID:</td>
                <td><?php echo $usuario ['id_usuarios'];?></td>
            </tr>
            <tr>
                <td>Nombre:</td>
                <td><?php echo $usuario ['nombre'];?></td>
            </tr>
            <tr>
                <td>Apellido:</td>
                <td><?php echo $usuario['apellido'];?></td>
            </tr>
            <tr>
                <td>Correo:</td>
                <td><?php echo $usuario ['correo']; ?></td>
            </tr>
            <tr>
                <td>Direccion:</td>
                <td><?php echo $usuario ['direccion']?></td>
            </tr>
            <tr>
                <td>No. Telefono:</td>
                <td><?php echo $usuario['telefono']?></td>
            </tr>
            <tr>
                <td>Regresar</td>
                <td></td>
            </tr>
        </table>
    </section>
</body>
</html>
