<?php
include 'menu_admin.php';
include 'conexion.php'
 ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Control - Rancheria "Los Tulipanes"</title>
    <link rel="stylesheet" href="css/vistas.css">
</head>
<body style="color:white;">

<p >Bienvenido </p>


<footer>
        <div class="pie">
            <p style="text-align: center;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
        </div>
    </footer>
</body>
</html
