<?php
include 'conexion.php';
include 'menu.php';
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Rancheria "Los Tulipanes"</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;1,400;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/vistas.css">
</head>
<body>

<!-- inicio Menu-->
    <!-- Fin Menu-->

   <h4 style="color:white;">Ingrese sus datos a continuacion</h4>

    <div>
   <form action="fun_login.php" method="post" id="formulario">
    <input type="text" name="correo" placeholder="correo">
    <input type="password" name="password" placeholder="Contraseña">
    <input type="submit" value="Enviar" id="boton">

   </form>
    </div>
          
          <div style="text-align:center;color:white;">¿No estas registrado? <a href="registro.php" style="color:white">Hazlo Aquí</a></div>
    
       <footer>
            <div>
                <redes style="color: white;">
                    <p1><img src="PNG/facebook.png" alt="facebook" width="20px" height="20px;"> https://www.facebook.com/lostulipanessomostodos </p1>
                    <p1><img src="PNG/telefono.png" alt="telefono" width="20px" height="20px;"> 9931838301 </p1>
                    <p1><img src="PNG/correo.png" alt="correo" width="20px" height="20px;"> RanchoTulipanes@gmail.com </p1>
                </redes>

                <p style="text-align: center; color: white;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
            </div>
        </footer>
</body>

</html>
