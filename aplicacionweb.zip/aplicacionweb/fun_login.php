<?php
//incluimos archivo de conexion a la base de datos
include 'conexion.php';

//declaramos los datos de la pagina login los cuales son dos
$correo = $_POST["correo"];
$password=$_POST["password"];
//declaramos la ejecucion de la funcion inicio para comprobar
$inicio = "SELECT * FROM usuarios WHERE correo='".$correo."' AND contraseña='".$password."'";
//aqui vemos si funciono o no
$resultado=$conexion->query($inicio) or die ("Error al comprobar usuario: ".mysqli_error($conexion));

//aqui hacemos la condicional para el inicio de sesion

$verifica = mysqli_num_rows($resultado);
    //si la variable count es mayor a 0 significa que si encontro algo
    if($verifica > 0) {
		$_SESSION['correo']=$correo;
		echo '<script>';
		echo 'alert("Bienvenido!!");';
		echo 'window.location.href="admin.php";';
		echo '</script>';
		}
		else
		{
			echo '<script>';
			echo 'alert("Datos de acceso incorrectos");';
			echo 'window.location.href="login.php";';
			echo '</script>';
		}

 ?>
