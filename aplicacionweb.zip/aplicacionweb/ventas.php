
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas - Rancheria "Los Tulipanes"</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;1,400;1,700&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="css/vistas.css">
</head>
<body>
    <!-- inicio Menu-->
  <?php include 'menu.php'; ?>
    <!-- Fin Menu-->
<!-- cuerpo de venta -->
<section class="tubo flex text-center">
  <div class="columna">
      <h2  style="text-align: center;">Ganado Vacuno</h2>
      <img src="imagenes/venta2.jpg" alt="VACA" class="imgcont" href="mue">
      <p>Vaca lechera  holstein</p>
      <hr>
      <p>Vacunas:</p>
      <p>Diarrea Viral Bovina (BVD)</p>
      <p>Influenza Tipo 3</p>
      <a href="vacuno.php" class="btn-precio">Ver Más</a>
  </div>
  <div class="columna">
      <h2  style="text-align: center;">Ganado Equino</h2>
      <img src="imagenes/venta3.jpg" alt="CABALLO" class="imgcont">
      <p>Caballo Azteca de <br> Registro Rienda Charra</p>
      <hr>
      <p>Vacunas:</p>
      <p>Influencia equina</p>
      <p>Rabia</p>
      <a href="equino.php" class="btn-precio">Ver Más</a>
  </div>

</section>
<!-- pie de pagina -->
<footer>
    <div class="pie">
        <p style="text-align: center;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
    </div>
</footer>
  <footer>
            <div>
                <redes style="color: white;">
                    <p1><img src="PNG/facebook.png" alt="facebook" width="20px" height="20px;"> https://www.facebook.com/lostulipanessomostodos </p1>
                    <p1><img src="PNG/telefono.png" alt="telefono" width="20px" height="20px;"> 9931838301 </p1>
                    <p1><img src="PNG/correo.png" alt="correo" width="20px" height="20px;"> RanchoTulipanes@gmail.com </p1>
                </redes>
                <p style="text-align: center; color: white;"> Empresa de Kevin Gabriel; Amir Ernesto &copy; 2020</p>
            </div>
        </footer>
</body>
</html>
