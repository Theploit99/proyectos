<?php
include 'menu.php';
include 'conexion.php';

$consulta = "SELECT * FROM `ganado` WHERE  `especie` = 'Equino'";

$resultado=mysqli_query($conexion, $consulta);
$nfilas=mysqli_num_rows($resultado);
error_reporting(0);
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/vistas.css">
    <title>Equinos - Rancheria "Los Tulipanes"</title>
</head>
<body>

<section>
  <table style="color:white; text-align:center;  width: 100%;
   border: 1px solid #fff;">
      <tr>
          <td>No.</td>
          <td>Foto</td>
          <td>peso</td>
          <td>color</td>
          <td>especie</td>
          <td>raza</td>
          <td>vacuna</td>
          <td>sexo</td>
          <td>Eliminar</td>

      </tr>
      <?php while ($ganado=mysqli_fetch_array($resultado)) {  ?>
        <tr >
          <td> <a href="detalle_ganado.php?id_ganado=<?php echo $ganado['id_ganado'];?>"><?php echo $ganado['id_ganado']; ?></a></td>
        <td><img src="<?php echo $ganado['foto'];  ?>"alt="muuu" style="height = "240"; width="255""></td>
          <td><?php    echo $ganado['peso'];    ?></td>
          <td><?php    echo $ganado['color'];    ?></td>
         <td><?php    echo $ganado['especie'];    ?></td>
          <td><?php    echo $ganado['raza'];    ?></td>
          <td><?php    echo $ganado['vacuna'];    ?></td>
           <td><?php    echo $ganado['sexo'];    ?></td>
           <td><a href="cat_ganado.php?eliminar=<?php echo $ganado['id_ganado']; ?> ">Eliminar</td>
      </tr>
      <?php  }  ?>
</table>




<a href="ventas.php" style="color:white; text-align:center;">Regresar</a>
</section>


</body>
</html>
