<?php
 include 'Base.php';
session_start();
$validar=$_SESSION['correo'];

if ($validar == null || $validar=='') {
    header('Location: index.html');
    die();
}
$consulta="SELECT * from usuarios where correo='$_SESSION[correo]'";
$resultado=mysqli_query($conexionn, $consulta);
$re=mysqli_fetch_array($resultado);

$re['cve_usuarios'];
 ?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="jquery/jquery.mobile-1.4.5.css">
	<link rel="stylesheet" href="estilos.css">
  <script src="jquery/jquery.min.js"></script>
  	<script src="jquery/jquery.mobile-1.4.5.min.js"></script>
  <title>Perfil</title>
</head>
<body>


        <div data-role="page" id="pageone" class="fondo">
		<div data-role="header" data-theme="b">
			<h1 style="text-align:center;">Editar Usuario </h1>
            <div data-role="navbar" data-iconpos="top" data-theme="b">
                <ul>
                <li><a rel="external" href="perfil.php" data-icon="user">Perfil</a></li>
                   <li><a rel="external" href="Menu.php" data-icon="bars">Menu</a></li>
                </ul>
            </div>
		</div>




      <div data-role="popup" id="editq" data-theme="a" class="ui-corner-all">

      </div>
      
       <div data-role="main" class="ui-content">
        <div class="ui-content" role="main" id="main">
         <ul data-role="listview" data-split-icon="gear" data-inset="true" data-theme="b">
            <li data-role="list-divider"> <span class="ui-li-count"></span></li>
            <li>
            <table data-role="table"  id="myTable">
            <thead>
              <tr>
                <th></th>
                <th data-priority="1">Usuario</th>
                <th data-priority="2">Contraseña</th>
             
           
              </tr>
            </thead>
            <tbody>
              <tr>
                <form id="form">

                  <td><input type="text" name="usuario" placeholder="usuario" data-mini="true" id="usuario" value="<?php echo $re['usuario']; ?>"></td>
                  <td><input type="text" name="password" placeholder="password" data-mini="true" id="password" value="<?php echo $re['password']; ?>"></td>        
                 <td> <input type="button" name="Guardar" value="Guardar" data-role="button" data-inline="true" data-theme="b" id="click"></td>
                 
                 <input type="hidden" name="cve_usuarios"   data-mini="true"  id="cve_usuarios" value="<?php echo $re['cve_usuarios']; ?>">
                </form>
               
              </tr>
            </tbody>
           </table></li>
         </ul>
         </div>
        </div>
    <div data-role="footer" data-theme="b" data-position="fixed">
        <div data-role="navbar" data-iconpos="top" data-theme="b" >
          
        </div>
		<h2><strong style="color: #EE2737;">Mi Inventario</strong></h2>
    </div>
    </div>
    </body>
    
    <script type="text/javascript" src="js/EditUsuario.js">

    </script>
    </html>