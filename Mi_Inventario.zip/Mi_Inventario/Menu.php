<?php
  include 'Base.php';
session_start();
$validar=$_SESSION['correo'];

if ($validar == null || $validar=='') {
    header('Location: index.html');
    die();
}
$consulta="SELECT * from usuarios where correo='$_SESSION[correo]'";
$resultado=mysqli_query($conexionn, $consulta);
$re=mysqli_fetch_array($resultado);

$re['cve_usuarios'];

$consulta1="SELECT * FROM productos where cve_usuarios='$re[cve_usuarios]' and cve_categorias='1' ORDER BY cve_categorias desc";
$resultado1=mysqli_query($conexionn, $consulta1);

$consulta2="SELECT * FROM productos where cve_usuarios='$re[cve_usuarios]' and   cve_categorias='2' ORDER BY  cve_categorias desc";
$resultado2=mysqli_query($conexionn, $consulta2);

$consulta3="SELECT * FROM productos where cve_usuarios='$re[cve_usuarios]' and  cve_categorias='3' ORDER BY  cve_categorias desc";
$resultado3=mysqli_query($conexionn, $consulta3);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="jquery/jquery.mobile-1.4.5.css">
	<link rel="stylesheet" href="estilos.css">
	<script src="jquery/jquery.min.js"></script>
	<script src="jquery/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
    <div data-role="page" id="pageone" class="fondo">
		<div data-role="header" data-theme="b">
			<h1 style="text-align:center;">Bienvenido </h1>
            <div data-role="navbar" data-iconpos="top" data-theme="b">
                <ul>
                <li><a rel="external" href="perfil.php" data-icon="user">Perfil de <?php echo ($re['usuario']); ?></a></li>
                   <li><a rel="external" href="inventario.php" data-icon="tag">Registro de Productos</a></li>
                </ul>
            </div>
		</div>

        <div class="ui-content" role="main" id="main">
        <ul data-role="listview" data-split-icon="gear" data-inset="true" data-theme="b">
         <ul data-role="listview">
            <li data-role="list-divider">  productos</li>
            <li data-role="collapsible" data-iconpos="right" data-inset="false" data-theme="b"> 
              <img src="imagenes/tecnologia.jpg" alt="tecnologia" style="margin-top: .5%; border-radius: 20%" height="100 xp" width="170 xp">
              <h2><strong style="color: #f7d917;">Tecnologia</strong></h2>
              <ul data-role="listview" data-theme="b">
                <?php while($tec=mysqli_fetch_array($resultado1)) {?>
                  <li>
                 
                      <h1>Nombre: <?php echo $tec['nombre'] ?></h1>
                      <p><strong style="font-size: 12px">Tamaño: <?php echo $tec['tamaño'] ?></strong></p>
                      <p><strong style="font-size: 12px">Color: <?php echo $tec['color'] ?></strong></p>
                      <p><strong style="font-size: 12px">Descripcion: <?php echo $tec['descripcion'] ?></strong></p>
                      <p><strong style="font-size: 11px">Cantidad: <?php echo $tec['cantidad'] ?></strong></p><br>
                      <p><strong style="font-size: 11px">Fecha de registro: <?php echo $tec['fecha'] ?></strong></p>
                      <p class="ui-li-aside"><strong>Precio: $<?php echo $tec['precio'] ?></strong></p> 
                  
                      <a  href="#myPopupDialog" data-rel="popup"  data-position-to="window" data-transition="fade"  class="ui-btn ui-corner-all ui-shadow ui-btn-inline">
                        <strong style="color:aqua;">Editar Producto</a></strong>

<div data-role="popup" id="myPopupDialog">
  <div data-theme="b" data-role="header">
    <h1 >Editar</h1>
  </div>

  <div data-role="main" class="ui-content">
    <h2></h2>
    <form ID="form">
            <label for="basic">Nombre del producto</label>
            <input type="text" value="<?php echo $tec['nombre'] ?>" name="nombre"  placeholder="Agregue el nombre"  id="nombre">
            <label for="basic">Tamaño del producto</label>
            <input type="text" value="<?php echo $tec['tamaño'] ?>"   name="Tamaño" data-mini="true" placeholder="Tamaño" id="tamaño">
            <label for="basic">Precio</label>
            <input type="number" value="<?php echo $tec['precio'] ?>"  name="Precio" data-mini="true" placeholder="Precio del producto" id="precio">
            <label for="basic">color</label>
            <input type="text" value="<?php echo $tec['color'] ?>"  name="Color" data-mini="true" placeholder="Color" id="color">
            <label for="basic">Descripcion del producto</label>
            <input type="text" value="<?php echo $tec['descripcion'] ?>"  name="Descripcion" data-mini="true" placeholder="Descripcion" id="descripcion">
            <label for="number">Cantidad</label>
            <input type="text" value="<?php echo $tec['cantidad'] ?>"  name="Cantidad" data-mini="true" placeholder="Cantidad" id="cantidad">
            <input type="hidden" name="Nombre"  readonly="readonly" value="<?php echo $tec['cve_producto']?>" id="cve_producto">
    
    <label for="day">Selecciona el tipo de categoria</label>

    <li class="ui-field-contain">
               <select name="" id="cve_categorias">
                 <option value="1">Tecnologia</option>
                 <option value="2">Moda</option>
                 <option value="3">Otros</option>
               </select>
            </li>
 
    </select>

            <input type="button" name="Actualizar" value="Actualizar" data-role="button" data-inline="true" data-theme="b" id="editProduct">
        </form>
    <a rel="external" href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b ui-icon-back ui-btn-icon-left" data-rel="back">Salir</a>

    <input type="button" value="Eliminar" data-role="button" data-inline="true" data-theme="b" id="eliminarprod">

                <?php } ?>
              </ul>
            </li>
           
                        
            <li data-role="collapsible" data-iconpos="right" data-inset="false" data-theme="b"> 
              <img src="imagenes/moda.jpg" alt="moda" style="margin-top: .5%; border-radius: 20% " height="100 xp" width="170 xp" >
              <h2><strong style="color: #f7d917;">Moda</strong></h2>             
              <ul data-role="listview" data-theme="b">
                <?php while($moda=mysqli_fetch_array($resultado2)) {?>
                  <li>
                  <h1>Nombre: <?php echo $moda['nombre'] ?></h1>
                      <p><strong style="font-size: 12px">Tamaño: <?php echo $moda['tamaño'] ?></strong></p>
                      <p><strong style="font-size: 12px">Color: <?php echo $moda['color'] ?></strong></p>
                      <p><strong style="font-size: 12px">Descripcion: <?php echo $moda['descripcion'] ?></strong></p>
                      <p><strong style="font-size: 11px">Cantidad: <?php echo $moda['cantidad'] ?></strong></p><br>
                      <p><strong style="font-size: 11px">Fecha de registro: <?php echo $moda['fecha'] ?></strong></p>
                      <p class="ui-li-aside"><strong>Precio: $<?php echo $moda['precio'] ?></strong></p> 

                      <a  href="#myPopupDialog" data-rel="popup"  data-position-to="window" data-transition="fade"  class="ui-btn ui-corner-all ui-shadow ui-btn-inline">
                      <strong style="color:aqua;">Editar Producto</strong></a>

<div data-role="popup" id="myPopupDialog">
  <div data-theme="b" data-role="header">
    <h1>Editar</h1>
  </div>

  <div data-role="main" class="ui-content">
    <h2></h2>
    <form ID="form">
            <label for="basic">Nombre del producto</label>
            <input type="text" value="<?php echo $moda['nombre'] ?>" name="nombre"  placeholder="Agregue el nombre"  id="nombre">
            <label for="basic">Tamaño del producto</label>
            <input type="text" value="<?php echo $moda['tamaño'] ?>"   name="Tamaño" data-mini="true" placeholder="Tamaño" id="tamaño">
            <label for="basic">Precio</label>
            <input type="number" value="<?php echo $moda['precio'] ?>"  name="Precio" data-mini="true" placeholder="Precio del producto" id="precio">
            <label for="basic">color</label>
            <input type="text" value="<?php echo $moda['color'] ?>"  name="Color" data-mini="true" placeholder="Color" id="color">
            <label for="basic">Descripcion del producto</label>
            <input type="text" value="<?php echo $moda['descripcion'] ?>"  name="Descripcion" data-mini="true" placeholder="Descripcion" id="descripcion">
            <label for="number">Cantidad</label>
            <input type="text" value="<?php echo $moda['cantidad'] ?>"  name="Cantidad" data-mini="true" placeholder="Cantidad" id="cantidad">
            <input type="hidden" value="<?php echo $moda['cve_producto'] ?>"  name="cve_producto" data-mini="true" id="cve_producto">

    <label for="day">Selecciona el tipo de categoria</label>
    <select name="cve_categorias" id="cve_categorias">
      <option value="1">Tecnologia</option>
      <option value="2">Moda</option>
      <option value="3">Otros</option>
    </select>

            <input type="button" name="Actualizar" value="Actualizar" data-role="button" data-inline="true" data-theme="b" id="editProduct">
        </form>
    <a rel="external" href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b ui-icon-back ui-btn-icon-left" data-rel="back">Salir</a>
                 
    <input type="button" value="Eliminar" data-role="button" data-inline="true" data-theme="b" id="eliminarprod">

                </li>
                <?php } ?>
              </ul>
            </li>

            <li data-role="collapsible" data-iconpos="right" data-inset="false" data-theme="b">
               <img src="imagenes/otros.jpg" alt="otros" style="margin-top: .5%; border-radius: 20%" height="100 xp" width="170 xp">
              <h2><strong style="color: #f7d917;">Otros</strong></h2>
              <ul data-role="listview" data-theme="b">
                <?php while($otro=mysqli_fetch_array($resultado3)) {?>
                  <li>
                   
                  <h1>Nombre: <?php echo $otro['nombre'] ?></h1>
                      <p><strong style="font-size: 12px">Tamaño: <?php echo $otro['tamaño'] ?></strong></p>
                      <p><strong style="font-size: 12px">Color: <?php echo $otro['color'] ?></strong></p>
                      <p><strong style="font-size: 12px">Descripcion: <?php echo $otro['descripcion'] ?></strong></p>
                      <p><strong style="font-size: 11px">Cantidad: <?php echo $otro['cantidad'] ?></strong></p><br>
                      <p><strong style="font-size: 11px">Fecha de registro: <?php echo $otro['fecha'] ?></strong></p>
                      <p class="ui-li-aside"><strong>Precio: $<?php echo $otro['precio'] ?></strong></p> 

                      <a  href="#myPopupDialog" data-rel="popup"  data-position-to="window" data-transition="fade"  class="ui-btn ui-corner-all ui-shadow ui-btn-inline">
                      <strong style="color:aqua;">Editar Producto</strong></a>

<div data-role="popup" id="myPopupDialog">
  <div data-theme="b" data-role="header">
    <h1>Editar</h1>
  </div>

  <div data-role="main" class="ui-content">
    <h2></h2>
    <form ID="form">
            <label for="basic">Nombre del producto</label>
            <input type="text" value="<?php echo $otro['nombre'] ?>" name="nombre"  placeholder="Agregue el nombre"  id="nombre">
            <label for="basic">Tamaño del producto</label>
            <input type="text" value="<?php echo $otro['tamaño'] ?>"   name="Tamaño" data-mini="true" placeholder="Tamaño" id="tamaño">
            <label for="basic">Precio</label>
            <input type="number" value="<?php echo $otro['precio'] ?>"  name="Precio" data-mini="true" placeholder="Precio del producto" id="precio">
            <label for="basic">color</label>
            <input type="text" value="<?php echo $otro['color'] ?>"  name="Color" data-mini="true" placeholder="Color" id="color">
            <label for="basic">Descripcion del producto</label>
            <input type="text" value="<?php echo $otro['descripcion'] ?>"  name="Descripcion" data-mini="true" placeholder="Descripcion" id="descripcion">
            <label for="number">Cantidad</label>
            <input type="text" value="<?php echo $otro['cantidad'] ?>"  name="Cantidad" data-mini="true" placeholder="Cantidad" id="cantidad">

            <input type="hidden" value="<?php echo $otro['cve_producto'] ?>"  name="cve_producto" data-mini="true" id="cve_producto">
            
    <label for="day">Selecciona el tipo de categoria</label>
    <select name="cve_categorias" id="cve_categorias">
      <option value="1">Tecnologia</option>
      <option value="2">Moda</option>
      <option value="3">Otros</option>
    </select>

            <input type="button" name="Actualizar" value="Actualizar" data-role="button" data-inline="true" data-theme="b" id="editProduct">
        </form>
    <a rel="external" href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b ui-icon-back ui-btn-icon-left" data-rel="back">Salir</a>
                       
    <input type="button" value="Eliminar" data-role="button" data-inline="true" data-theme="b" id="eliminarprod">

                </li>
                <?php } ?>
              </ul>
            </li>
         </ul>
        </ul>

    </div>

    <br>
    <br>
    <br>
    <img src="imagenes/inventario.jpg" alt="tecnologia"  height="200 xp" width="420 xp">
 

        <div data-role="footer" data-theme="b" data-position="fixed">
		    <h2><strong style="color: #EE2737;">Mi Inventario</strong></h2>
        </div>
    </div>
</body>
<script type="text/javascript" src="js\editProduct.js"></script>
<script type="text/javascript" src="js\eliminarprod.js"></script>
</html>
