<?php

include 'Base.php';

$cve_producto=$_POST ["cve_producto"];
$delete= "DELETE from productos where cve_producto=$cve_producto";

  if(mysqli_query($conexionn,$delete)){
      echo true;
  }else{
      echo "Error: " . $insert . "<br>" . mysqli_error($conexionn);
      echo false;
  }

mysqli_close($conexionn);


?>