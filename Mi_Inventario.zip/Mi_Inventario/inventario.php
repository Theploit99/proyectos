<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.5.css">
    <link rel="stylesheet" href="estilos.css">

	<script src="jquery/jquery.min.js"></script>
	<script src="jquery/jquery.mobile-1.4.5.min.js"></script>
    <title>registro de Productos</title>
</head>
<body>

<div data-role="page" >
<div data-role="navbar" data-iconpos="top" data-theme="b">
<a rel="external" href="Menu.php" data-Icon="home" data-theme="b"> Inicio </a>
</div>
<div data-role="header" data-theme="b" >

<h1 style="text-align:center;">Registro</h1>
</div>

<div   class="ui-content" role="main"  >
        <form ID="form">
            <label for="basic">Nombre del producto</label>
            <input type="text" name="Nombre" data-mini="true" placeholder="Producto" id="nombre">
            <label for="basic">Tamaño del producto</label>
            <input type="text" name="Tamaño" data-mini="true" placeholder="Tamaño" id="tamaño">
            <label for="basic">Precio</label>
            <input type="number" name="Precio" data-mini="true" placeholder="Precio del producto" id="precio">
            <label for="basic">color</label>
            <input type="text" name="Color" data-mini="true" placeholder="Color" id="color">
            <label for="basic">Descripcion del producto</label>
            <input type="text" name="Descripcion" data-mini="true" placeholder="Descripcion" id="descripcion">
            <label for="number">Cantidad</label>
            <input type="text" name="Cantidad" data-mini="true" placeholder="Cantidad" id="cantidad">

            
    <label for="day">Selecciona el tipo de categoria</label>
    <select name="cve_categorias" id="cve_categorias">
      <option value="1">Tecnologia</option>
      <option value="2">Moda</option>
      <option value="3">Otros</option>
    </select>


            <input type="button" name="Enviar" value="Enviar" data-role="button" data-inline="true" data-theme="b" id="click">
        </form>
    </div>

</form>

<div data-role="footer" data-theme="b" data-position="fixed">
		    <h2><strong style="color: #EE2737;">Mi Inventario</strong></h2> 
        </div>

</div> 
</body>
<script type="text/javascript" src="js\registroproduc.js"></script>
</html>