$("#eliminarprod").click(function(){
    event.preventDefault();

    var cve_producto = document.getElementById('cve_producto').value;

    $.post("eliminarprod.php",{
        cve_producto:cve_producto}, function(respuesta){
                if (respuesta == true) {
                    alert("Se ha eliminado el producto :)");
                    $.mobile.changePage("Menu.php?cve_producto=");
                }else {
                    alert ("Error :( ");
                }
    });

})