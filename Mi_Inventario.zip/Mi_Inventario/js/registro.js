
  $("#solicitar").on("click", function(){
    event.preventDefault();
    var usuario = document.getElementById('usuario').value;
    var correo = document.getElementById('correo').value;
    var password = document.getElementById('pass').value;
    var password1 = document.getElementById('pass1').value;
  
    if (usuario=="") {
      alert("Olvidaste ingresar un Usuario");         
      return false;}
    if (correo=="") {
      alert("Olvidaste ingresar un Correo");
      return false;
    }
    if (password=="") {
      alert("Olvidaste ingresar una Contraseña");
      return false;
    }
    if (password1=="") {
      alert("Confirma tu Contraseña");
      return false;
    }
    if (password!=password1) {
      alert("Tus contraseñas no coinciden");
      return false;
    }

    $.post("php/registroUsu.php",{
      usuario:usuario,
      correo:correo,
      password:password,
      }, function(respuesta){
          if (respuesta == false) {
            alert("Error en el registro :(")
          }else {
            alert ("Registro Exitoso :)")
          }
    });
  })
