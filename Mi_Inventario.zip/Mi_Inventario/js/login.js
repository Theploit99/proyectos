  $("#click").on("click", function(){
  event.preventDefault();
  var correo=document.getElementById('correo').value;
  var password=document.getElementById('password').value;

  if (correo=="") {
    alert("Olvidaste ingresar tu correo :(");
    return false;
  }else if (password=="") {
    alert("Olvidaste ingresar tu contraseña :(");
    return false;
  }


  $.post("php/login.php",{
    correo:correo,
    password:password}, function(respuesta){
        if (respuesta == true) {
          $.mobile.changePage("Menu.php");
        }else {
          alert ("Datos erroneos")
        }
  });

})
