
$("#click").on("click", function(){
    event.preventDefault();
    var usuario = document.getElementById('usuario').value;
    var password = document.getElementById('password').value;
 

    var cve_usuarios = document.getElementById('cve_usuarios').value;

    if (usuario=="") {
      alert("ingrese el correo");
      return false;
    }
    if (password=="") {
      alert("ingrese la contraseña");
      return false;
    }

 

    $.post("consul.php",{
 
      usuario:usuario,
      password:password,
      cve_usuarios:cve_usuarios,
      }, function(respuesta){
          if (respuesta == true) {
            alert("Datos actualizados, Felicidades :)");


          }else {
            alert (" error :( ");
          }
    });
  })