

$("#editProduct").click(function(){
	event.preventDefault();
	var nombre = document.getElementById('nombre').value;
	var tamaño = document.getElementById('tamaño').value;
	var precio = document.getElementById('precio').value;
	var color = document.getElementById('color').value;
	var descripcion = document.getElementById('descripcion').value;
	var cantidad = document.getElementById('cantidad').value
	var cve_categorias = document.getElementById('cve_categorias').value;
	var cve_producto = document.getElementById('cve_producto').value;

 


	if (nombre.length==""){
		alert("olvidaste ingresar el nombre");
		return false;
	}else if (tamaño.length=="") {
		alert("olvidaste ingresar el tamaño");
		return false;
	} else if (precio=="") {
		alert("olvidaste ingresar el precio");

	}else if (color == "") {
		alert("olvidaste ingresar el color ");
		return false;
	}else if(descripcion == ""){
		alert("olvidaste ingresar la descripcion ");
		return false;
	}
	else if(cantidad == ""){
		alert("olvidaste ingresar la cantidad ");
		return false;

	}
	else if(cve_categorias == ""){
		alert("olvidaste ingresar la categoria");
		return false;
	}

 

	$.post("editProduct.php",{
	nombre:nombre,
	tamaño:tamaño,
	precio:precio,
	color:color,
	descripcion:descripcion,
	cantidad:cantidad,
	cve_categorias:cve_categorias,
	cve_producto:cve_producto,
	
	}, function(respuesta){
				if (respuesta == true) {
					alert("Datos Actualizados");
					$.mobile.changePage("Menu.php?cve_producto=");
				 
				}else {
					alert ("Error");
				}
	});

})
