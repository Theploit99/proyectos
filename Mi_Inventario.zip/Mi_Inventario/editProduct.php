<?php

include 'Base.php';


$nombre =$_POST ["nombre"];
$tamaño = $_POST ["tamaño"];
$precio= $_POST ["precio"];
$color = $_POST ["color"];
$descripcion =$_POST ["descripcion"];
$cantidad =$_POST ["cantidad"];
$cve_categorias = $_POST ["cve_categorias"];
$cve_producto = $_POST ["cve_producto"];

$insert= "UPDATE productos SET nombre='$nombre', tamaño='$tamaño', precio='$precio', color='$color',
descripcion='$descripcion', cantidad='$cantidad', cve_categorias='$cve_categorias'   WHERE cve_producto='$cve_producto'";
if(mysqli_query($conexionn,$insert)) {
  echo true;
}else{
  echo "Error: " . $insert . "<br>" . mysqli_error($conexionn);
  echo false;
}

mysqli_close($conexionn);

?>
