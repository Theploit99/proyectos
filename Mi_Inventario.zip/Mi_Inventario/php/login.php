<?php

include '../Base.php';
session_start();

$_SESSION['correo']=$_POST["correo"];
$_SESSION['password']=$_POST["password"];

$consulta="SELECT * from usuarios where correo='$_SESSION[correo]' and password='$_SESSION[password]'";
$resultado=mysqli_query($conexionn, $consulta);
$re=mysqli_num_rows($resultado);

if (!$re) {
  echo false;
  session_destroy();
}else {
  echo true;
}


mysqli_close($conexionn);
?>
