<?php

include '../Base.php';


 $nombre = $_POST['nombre'];
 $tamaño = $_POST['tamaño'];
 $precio = $_POST['precio'];
 $color = $_POST['color'];
 $descripcion = $_POST['descripcion'];
 $cantidad = $_POST['cantidad'];
 $cve_categorias = $_POST['cve_categorias'];
 $fecha = date('y-m-d');


 session_start();
 $user=$_SESSION['correo'];

$consulta="SELECT * from usuarios where correo='$user'";
$resultado=mysqli_query($conexionn, $consulta);
$re=mysqli_fetch_array($resultado);

$insert= "INSERT INTO productos(cve_categorias, cve_usuarios, nombre, tamaño, precio, color, descripcion, cantidad , fecha) 
VALUES('$cve_categorias','$re[cve_usuarios]', '$nombre', '$tamaño', '$precio', '$color', '$descripcion', '$cantidad' ,'$fecha')";

  if(mysqli_query($conexionn,$insert)){
      echo true;
  }else{
      echo "Error: " . $insert . "<br>" . mysqli_error($conexionn);
      echo false;
  }

mysqli_close($conexionn);

?>
