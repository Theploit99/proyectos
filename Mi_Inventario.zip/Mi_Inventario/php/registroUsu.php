<?php

  include '../Base.php';

  $usuario =$_POST ["usuario"];
  $correo =$_POST ["correo"];
  $password =$_POST ["password"];

  $insertPERS= "INSERT INTO usuarios( correo, password, usuario) VALUES('$correo', '$password', '$usuario')";

  $consulta= "SELECT * from usuarios where correo='$correo'";
  $resultado=mysqli_query($conexionn, $consulta);
  $re=mysqli_fetch_assoc($resultado);

  if ($re['correo']) {
    echo false;
  }else {
    if (mysqli_query($conexionn,$insertPERS)) { 
      echo true;
    }else {
      echo "ERROR: ".$insertPERS."<br>".mysqli_error($conexionn);
      echo false;
    }
  }

  mysqli_close($conexionn);
?>
