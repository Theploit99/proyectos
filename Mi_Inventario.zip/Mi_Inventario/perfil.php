<?php

  include 'Base.php';
session_start();
$validar=$_SESSION['correo'];

if ($validar == null || $validar==' ') {
    header('Location: index.html');
    die();

}

$consulta="SELECT * from usuarios where correo ='$_SESSION[correo]'";
$resultado=mysqli_query($conexionn, $consulta);
$re=mysqli_fetch_array($resultado);

?>


<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">}
  <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="jquery/jquery.mobile-1.4.5.css">
	<link rel="stylesheet" href="estilos.css">
	<script src="jquery/jquery.min.js"></script>
	<script src="jquery/jquery.mobile-1.4.5.min.js"></script>
  <link rel="stylesheet" href="css/css.css">
  <title>Perfil</title>
</head>
<body>

    <div data-role="page" class="fondo">
      <div data-role="header" data-theme="b" >
        <h1>Perfil de usuario</h1>
        <div data-role="navbar" data-iconpos="top" data-theme="b">
                <ul>
                <li><a rel="external" href="cerrar_sesion.php" data-icon="power">Cerrar Sesión</a></li>
                <li><a  rel="external" href="Menu.php" data-icon="bars">Menu</a></li>
                </ul>
        </div>
      </div>

       <div data-role="main" class="ui-content">
         <p style="text-align: center"></p>
         <div class="ui-content" role="main" id="main">
           <ul data-role="listview" data-split-icon="gear" data-inset="true" data-theme="b">
           <img src="imagenes/Usuarioo.jpg" alt="Usuario" style="margin-top: .5%; border-radius: 20%" height="100 xp" width="130 xp"> 
             <li data-role="list-divider"><?php echo $re['usuario']; ?><span class="ui-li-count"></span></li>
             <li>

             <table data-role="table"  id="myTable">
              <thead>
                <tr>
                  <th></th>
                  <th data-priority="1">correo</th>
                  <th data-priority="2">Contraseña</th>

                </tr>
              </thead>
              <tbody>
                <tr>
                  <td></td>
                  <td><?php echo $re['correo']; ?></td>
                  <td><?php echo $re['password']; ?></td>
                </tr>
              </tbody>
             </table></li></ul></div>


    <div data-role="footer" data-theme="b" data-position="fixed">
        <div data-role="navbar" data-iconpos="top" data-theme="b" >
            <ul>
               <li><a rel="external" href="EditUsuario.php" data-Icon="edit" rel="external"> Editar</a></li>
            </ul>
        </div>
		<h2><strong style="color: #EE2737;">Mi Inventario</strong></h2>
    </div>
    </div>
  </body>
</html>
