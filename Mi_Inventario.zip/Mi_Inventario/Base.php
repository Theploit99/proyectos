<?php
$conexionn= mysqli_connect("localhost","root","","test");
if($conexionn === false){
    die("Error en la conexion a la base de datos, Disculpe las molestias :/" . mysqli_connect_error());

}
else{

}
?>
