<?php
  include 'Base.php';

 
  $usuario = $_POST ["usuario"];
  $password =$_POST ["password"];
  $cve_usuarios =$_POST["cve_usuarios"];
 
   $consulta= "UPDATE usuarios SET   usuario='$usuario',
   password='$password'
    WHERE cve_usuarios='$cve_usuarios'";


if (mysqli_query($conexionn,$consulta)) {
  echo true;
}else {
  echo "ERROR: ".$consulta."<br>".mysqli_error($conexionn);
  echo false;
}

  mysqli_close($conexionn);
?>